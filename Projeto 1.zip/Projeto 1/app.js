// ===== MonitorIA — App Logic =====
(function () {
  'use strict';

  // --- State ---
  let monitores = JSON.parse(localStorage.getItem('monitoria_monitores') || '[]');
  let sessoes = JSON.parse(localStorage.getItem('monitoria_sessoes') || '[]');
  let nextSessaoId = sessoes.length ? Math.max(...sessoes.map(s => s.id)) + 1 : 1;

  function save() {
    localStorage.setItem('monitoria_monitores', JSON.stringify(monitores));
    localStorage.setItem('monitoria_sessoes', JSON.stringify(sessoes));
  }

  // --- Helpers ---
  const $ = id => document.getElementById(id);
  const DIAS = ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
  const HORARIOS = ['08:00', '09:00', '10:00', '11:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00'];
  const TITLES = { dashboard: 'Dashboard', monitores: 'Monitores', agendamento: 'Agendamento', grade: 'Grade Semanal', historico: 'Histórico' };

  function toast(msg, type = 'info') {
    const c = $('toast-container');
    const icons = { success: '✅', error: '❌', info: 'ℹ️' };
    const t = document.createElement('div');
    t.className = `toast ${type}`;
    t.innerHTML = `<span class="toast-icon">${icons[type]}</span><span>${msg}</span>`;
    c.appendChild(t);
    setTimeout(() => { t.style.opacity = '0'; t.style.transform = 'translateX(100%)'; setTimeout(() => t.remove(), 300); }, 3500);
  }

  function formatDate(iso) {
    if (!iso) return '—';
    const d = new Date(iso);
    return d.toLocaleDateString('pt-BR') + ' ' + d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  }

  // --- Navigation ---
  document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', e => {
      e.preventDefault();
      const view = link.dataset.view;
      document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
      link.classList.add('active');
      document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
      $('view-' + view).classList.add('active');
      $('page-title').textContent = TITLES[view] || view;
      if (view === 'grade') renderGrade();
      if (view === 'historico') renderHistorico();
      if (view === 'dashboard') updateDashboard();
      if (view === 'agendamento') { populateMonitorSelect(); renderSessionsList(); }
      if (view === 'monitores') renderMonitores();
      $('sidebar').classList.remove('open');
    });
  });

  // --- Topbar ---
  $('menu-toggle').addEventListener('click', () => $('sidebar').classList.toggle('open'));
  (function setDate() {
    const now = new Date();
    $('topbar-date').textContent = now.toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  })();

  // --- Availability Grid (Modal) ---
  function buildAvailGrid(selected) {
    const grid = $('availability-grid');
    grid.innerHTML = '<div class="avail-slot avail-header"></div>';
    DIAS.forEach(d => { const h = document.createElement('div'); h.className = 'avail-slot avail-header'; h.textContent = d.slice(0, 3); grid.appendChild(h); });
    HORARIOS.forEach(hr => {
      const lbl = document.createElement('div');
      lbl.className = 'avail-slot avail-header';
      lbl.textContent = hr;
      grid.appendChild(lbl);
      DIAS.forEach(d => {
        const slot = document.createElement('div');
        slot.className = 'avail-slot';
        slot.textContent = hr;
        slot.dataset.dia = d;
        slot.dataset.hora = hr;
        if (selected && selected.some(s => s.dia === d && s.hora === hr)) slot.classList.add('selected');
        slot.addEventListener('click', () => slot.classList.toggle('selected'));
        grid.appendChild(slot);
      });
    });
  }

  function getSelectedSlots() {
    return [...$('availability-grid').querySelectorAll('.avail-slot.selected')].map(s => ({ dia: s.dataset.dia, hora: s.dataset.hora }));
  }

  // --- Monitor CRUD ---
  function openMonitorModal(monitor) {
    $('modal-monitor').classList.add('show');
    $('form-monitor').reset();
    $('mon-vagas').value = monitor ? monitor.vagas : 1;
    buildAvailGrid(monitor ? monitor.disponibilidade : null);
    $('form-monitor').dataset.editId = monitor ? monitor.id : '';
    $('modal-monitor-title').textContent = monitor ? 'Editar Monitor' : 'Cadastrar Monitor';
    if (monitor) {
      $('mon-nome').value = monitor.nome;
      $('mon-ra').value = monitor.ra;
      $('mon-disciplina').value = monitor.disciplina;
      $('mon-email').value = monitor.email || '';
      $('mon-local').value = monitor.local || '';
      $('mon-vagas').value = monitor.vagas;
    }
  }

  function closeMonitorModal() { $('modal-monitor').classList.remove('show'); }
  $('btn-novo-monitor').addEventListener('click', () => openMonitorModal(null));
  $('close-modal-monitor').addEventListener('click', closeMonitorModal);
  $('cancel-monitor').addEventListener('click', closeMonitorModal);

  $('form-monitor').addEventListener('submit', function (e) {
    e.preventDefault();
    const nome = $('mon-nome').value.trim();
    const ra = $('mon-ra').value.trim();
    const disciplina = $('mon-disciplina').value.trim();
    const disponibilidade = getSelectedSlots();
    if (!nome || !ra || !disciplina) { toast('Preencha todos os campos obrigatórios', 'error'); return; }
    if (!disponibilidade.length) { toast('Selecione ao menos um horário', 'error'); return; }

    const editId = this.dataset.editId;
    if (editId) {
      const m = monitores.find(x => x.id === editId);
      if (m) { Object.assign(m, { nome, ra, disciplina, email: $('mon-email').value.trim(), local: $('mon-local').value.trim(), vagas: +$('mon-vagas').value, disponibilidade }); }
      toast('Monitor atualizado!', 'success');
    } else {
      monitores.push({ id: 'mon_' + Date.now(), nome, ra, disciplina, email: $('mon-email').value.trim(), local: $('mon-local').value.trim(), vagas: +$('mon-vagas').value, disponibilidade });
      toast('Monitor cadastrado!', 'success');
    }
    save();
    closeMonitorModal();
    renderMonitores();
    updateDashboard();
  });

  function deleteMonitor(id) {
    monitores = monitores.filter(m => m.id !== id);
    save();
    renderMonitores();
    updateDashboard();
    toast('Monitor removido', 'info');
  }

  function renderMonitores(filter) {
    const grid = $('monitors-grid');
    let list = monitores;
    if (filter) { const f = filter.toLowerCase(); list = list.filter(m => m.nome.toLowerCase().includes(f) || m.disciplina.toLowerCase().includes(f)); }
    if (!list.length) { grid.innerHTML = '<div class="empty-state full-width"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg><p>Nenhum monitor encontrado.</p></div>'; return; }
    grid.innerHTML = list.map(m => `
      <div class="monitor-card">
        <div class="monitor-card-header">
          <div class="monitor-avatar">${m.nome.charAt(0).toUpperCase()}</div>
          <div><div class="monitor-name">${m.nome}</div><div class="monitor-disc">${m.disciplina}</div><div class="monitor-ra">RA: ${m.ra}</div></div>
        </div>
        ${m.local ? `<div class="monitor-detail">📍 ${m.local}</div>` : ''}
        ${m.email ? `<div class="monitor-detail">✉️ ${m.email}</div>` : ''}
        <div class="monitor-detail">👥 ${m.vagas} vaga(s) por sessão</div>
        <div class="monitor-slots">${m.disponibilidade.map(d => `<span class="slot-tag">${d.dia.slice(0, 3)} ${d.hora}</span>`).join('')}</div>
        <div class="monitor-actions">
          <button class="btn btn-sm btn-ghost" data-action="edit" data-id="${m.id}">✏️ Editar</button>
          <button class="btn btn-sm btn-danger" data-action="delete" data-id="${m.id}">🗑️ Remover</button>
        </div>
      </div>
    `).join('');
  }

  // Event delegation for monitor edit/delete buttons
  $('monitors-grid').addEventListener('click', function(e) {
    const btn = e.target.closest('[data-action]');
    if (!btn) return;
    const action = btn.dataset.action;
    const id = btn.dataset.id;
    if (action === 'edit') {
      openMonitorModal(monitores.find(m => m.id === id));
    } else if (action === 'delete') {
      if (btn.dataset.confirmDelete === 'true') {
        deleteMonitor(id);
      } else {
        btn.dataset.confirmDelete = 'true';
        btn.textContent = '⚠️ Confirmar?';
        setTimeout(() => {
          if (btn.isConnected) {
            btn.dataset.confirmDelete = 'false';
            btn.textContent = '🗑️ Remover';
          }
        }, 3000);
      }
    }
  });

  $('search-monitor').addEventListener('input', e => renderMonitores(e.target.value));

  // --- Agendamento ---
  function populateMonitorSelect() {
    const sel = $('ag-monitor');
    sel.innerHTML = '<option value="">— Escolha um monitor —</option>';
    monitores.forEach(m => { const o = document.createElement('option'); o.value = m.id; o.textContent = `${m.nome} — ${m.disciplina}`; sel.appendChild(o); });
  }

  $('ag-monitor').addEventListener('change', function () {
    const m = monitores.find(x => x.id === this.value);
    const grp = $('ag-disponibilidade-group');
    const sel = $('ag-horario');
    if (!m) { grp.style.display = 'none'; return; }
    grp.style.display = 'block';
    sel.innerHTML = '<option value="">— Selecione um horário —</option>';
    m.disponibilidade.forEach((d, i) => { const o = document.createElement('option'); o.value = i; o.textContent = `${d.dia} — ${d.hora}`; sel.appendChild(o); });
  });

  document.querySelectorAll('.toggle-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.toggle-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      $('ag-modalidade').value = btn.dataset.value;
    });
  });

  $('form-agendamento').addEventListener('submit', function (e) {
    e.preventDefault();
    const aluno = $('ag-aluno').value.trim();
    const ra = $('ag-ra').value.trim();
    const monId = $('ag-monitor').value;
    const horIdx = $('ag-horario').value;
    const duvida = $('ag-duvida').value.trim();
    const modalidade = $('ag-modalidade').value;
    if (!aluno || !ra || !monId || horIdx === '' || !duvida) { toast('Preencha todos os campos obrigatórios', 'error'); return; }
    const monitor = monitores.find(m => m.id === monId);
    if (!monitor) { toast('Monitor não encontrado', 'error'); return; }
    const slot = monitor.disponibilidade[+horIdx];
    sessoes.push({ id: nextSessaoId++, aluno, ra, monitorId: monId, monitorNome: monitor.nome, disciplina: monitor.disciplina, dia: slot.dia, hora: slot.hora, duvida, modalidade, status: 'pendente', criadoEm: new Date().toISOString() });
    save();
    this.reset();
    $('ag-disponibilidade-group').style.display = 'none';
    $('ag-modalidade').value = 'presencial';
    document.querySelectorAll('.toggle-btn').forEach(b => b.classList.remove('active'));
    $('tog-presencial').classList.add('active');
    toast('Sessão solicitada com sucesso!', 'success');
    renderSessionsList();
    updateDashboard();
    updateNotifications();
  });

  function renderSessionsList(filter) {
    const container = $('sessions-list-full');
    let list = sessoes.slice().reverse();
    if (filter && filter !== 'todas') list = list.filter(s => s.status === filter);
    if (!list.length) { container.innerHTML = '<div class="empty-state"><p>Nenhuma sessão encontrada</p></div>'; return; }
    container.innerHTML = list.map(s => `
      <div class="session-item">
        <div class="session-status-dot ${s.status}"></div>
        <div class="session-info">
          <div class="session-title">${s.aluno} → ${s.monitorNome}</div>
          <div class="session-meta">${s.disciplina} · ${s.dia} ${s.hora} · <span class="modalidade-badge">${s.modalidade}</span></div>
          <div class="session-meta">${s.duvida}</div>
          <div class="session-actions">
            ${s.status === 'pendente' ? `<button class="btn btn-sm btn-success" data-sessao-action="confirmar" data-sessao-id="${s.id}">✔ Confirmar</button><button class="btn btn-sm btn-danger" data-sessao-action="cancelar" data-sessao-id="${s.id}">✖ Cancelar</button>` : ''}
            ${s.status === 'confirmada' ? `<button class="btn btn-sm btn-primary" data-sessao-action="concluir" data-sessao-id="${s.id}">✔ Concluir</button><button class="btn btn-sm btn-danger" data-sessao-action="cancelar" data-sessao-id="${s.id}">✖ Cancelar</button>` : ''}
            <span class="status-badge ${s.status}">${s.status.charAt(0).toUpperCase() + s.status.slice(1)}</span>
          </div>
        </div>
      </div>
    `).join('');
  }

  function handleSessaoAction(id, action) {
    const s = sessoes.find(x => x.id === id);
    if (!s) return;
    if (action === 'confirmar') { s.status = 'confirmada'; toast('Sessão confirmada!', 'success'); }
    else if (action === 'cancelar') { s.status = 'cancelada'; toast('Sessão cancelada', 'info'); }
    else if (action === 'concluir') { s.status = 'concluida'; toast('Sessão concluída!', 'success'); }
    save(); renderSessionsList(); updateDashboard(); updateNotifications();
  }

  // Event delegation for session action buttons
  $('sessions-list-full').addEventListener('click', function(e) {
    const btn = e.target.closest('[data-sessao-action]');
    if (!btn) return;
    handleSessaoAction(+btn.dataset.sessaoId, btn.dataset.sessaoAction);
  });

  document.querySelectorAll('.filter-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.filter-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      renderSessionsList(tab.dataset.filter);
    });
  });

  // --- Dashboard ---
  function updateDashboard() {
    $('dash-monitores').textContent = monitores.length;
    const agendadas = sessoes.filter(s => s.status === 'confirmada' || s.status === 'pendente').length;
    const pendentes = sessoes.filter(s => s.status === 'pendente').length;
    const concluidas = sessoes.filter(s => s.status === 'concluida').length;
    $('dash-sessoes').textContent = agendadas;
    $('dash-pendentes').textContent = pendentes;
    $('dash-concluidas').textContent = concluidas;
    // Animate values
    document.querySelectorAll('.stat-value').forEach(el => { el.style.transform = 'scale(1.15)'; setTimeout(() => el.style.transform = 'scale(1)', 200); });

    // Upcoming
    const upcoming = sessoes.filter(s => s.status === 'confirmada' || s.status === 'pendente').slice(-5).reverse();
    $('upcoming-count').textContent = upcoming.length;
    const ul = $('upcoming-list');
    if (!upcoming.length) { ul.innerHTML = '<div class="empty-state"><p>Nenhuma sessão agendada</p></div>'; }
    else {
      ul.innerHTML = upcoming.map(s => `
        <div class="session-item">
          <div class="session-status-dot ${s.status}"></div>
          <div class="session-info">
            <div class="session-title">${s.aluno} → ${s.monitorNome}</div>
            <div class="session-meta">${s.dia} ${s.hora} · ${s.disciplina}</div>
          </div>
        </div>
      `).join('');
    }

    // Mini monitors
    const ml = $('monitor-list-mini');
    if (!monitores.length) { ml.innerHTML = '<div class="empty-state"><p>Nenhum monitor cadastrado</p></div>'; }
    else {
      ml.innerHTML = monitores.map(m => `
        <div class="mini-monitor-item">
          <div class="mini-avatar">${m.nome.charAt(0).toUpperCase()}</div>
          <div><div class="mini-name">${m.nome}</div><div class="mini-disc">${m.disciplina}</div></div>
          <div class="mini-status"></div>
        </div>
      `).join('');
    }
  }

  // --- Notifications ---
  function updateNotifications() {
    const p = sessoes.filter(s => s.status === 'pendente').length;
    const badge = $('notif-badge');
    if (p > 0) { badge.style.display = 'flex'; badge.textContent = p; } else { badge.style.display = 'none'; }
  }

  // --- Grade Semanal ---
  function populateGradeFilter() {
    const sel = $('grade-monitor-filter');
    sel.innerHTML = '<option value="todos">Todos os Monitores</option>';
    monitores.forEach(m => { const o = document.createElement('option'); o.value = m.id; o.textContent = `${m.nome} — ${m.disciplina}`; sel.appendChild(o); });
  }

  function renderGrade() {
    populateGradeFilter();
    const filterId = $('grade-monitor-filter').value;
    const container = $('grade-container');
    let mons = filterId === 'todos' ? monitores : monitores.filter(m => m.id === filterId);
    if (!mons.length) { container.innerHTML = '<div class="empty-state"><p>Nenhum monitor para exibir na grade</p></div>'; return; }

    let html = '<table class="grade-table"><thead><tr><th>Horário</th>';
    DIAS.forEach(d => html += `<th>${d}</th>`);
    html += '</tr></thead><tbody>';
    HORARIOS.forEach(hr => {
      html += `<tr><td><strong>${hr}</strong></td>`;
      DIAS.forEach(d => {
        let cellContent = '';
        mons.forEach(m => {
          const hasSlot = m.disponibilidade.some(s => s.dia === d && s.hora === hr);
          if (hasSlot) {
            const session = sessoes.find(s => s.monitorId === m.id && s.dia === d && s.hora === hr && (s.status === 'confirmada' || s.status === 'pendente'));
            if (session) {
              const cls = session.status === 'confirmada' ? 'grade-cell-session' : 'grade-cell-pending';
              cellContent += `<div class="${cls}">${m.nome.split(' ')[0]}<br>${session.aluno.split(' ')[0]} (${session.status})</div>`;
            } else {
              cellContent += `<div class="grade-cell-available">${m.nome.split(' ')[0]}<br>Disponível</div>`;
            }
          }
        });
        html += `<td>${cellContent}</td>`;
      });
      html += '</tr>';
    });
    html += '</tbody></table>';
    container.innerHTML = html;
  }
  $('grade-monitor-filter').addEventListener('change', renderGrade);

  // --- Histórico ---
  function renderHistorico(searchTerm, statusFilter) {
    const tbody = $('historico-tbody');
    let list = sessoes.slice().reverse();
    if (statusFilter && statusFilter !== 'todos') list = list.filter(s => s.status === statusFilter);
    if (searchTerm) { const f = searchTerm.toLowerCase(); list = list.filter(s => s.aluno.toLowerCase().includes(f) || s.monitorNome.toLowerCase().includes(f) || s.disciplina.toLowerCase().includes(f)); }
    if (!list.length) { tbody.innerHTML = '<tr><td colspan="8" class="td-empty">Nenhum registro encontrado</td></tr>'; return; }
    tbody.innerHTML = list.map(s => `
      <tr>
        <td>${s.id}</td>
        <td>${formatDate(s.criadoEm)}</td>
        <td>${s.aluno} <span style="color:var(--text-muted);font-size:.72rem">(${s.ra})</span></td>
        <td>${s.monitorNome}</td>
        <td>${s.disciplina}</td>
        <td><span class="modalidade-badge">${s.modalidade}</span></td>
        <td><span class="status-badge ${s.status}">${s.status.charAt(0).toUpperCase() + s.status.slice(1)}</span></td>
        <td>
          ${s.status === 'pendente' ? `<button class="btn btn-sm btn-success" data-hist-action="confirmar" data-hist-id="${s.id}">✔</button><button class="btn btn-sm btn-danger" data-hist-action="cancelar" data-hist-id="${s.id}">✖</button>` : '—'}
        </td>
      </tr>
    `).join('');
  }
  $('hist-search').addEventListener('input', () => renderHistorico($('hist-search').value, $('hist-status').value));
  $('hist-status').addEventListener('change', () => renderHistorico($('hist-search').value, $('hist-status').value));

  // Event delegation for historico table action buttons
  $('historico-tbody').addEventListener('click', function(e) {
    const btn = e.target.closest('[data-hist-action]');
    if (!btn) return;
    handleSessaoAction(+btn.dataset.histId, btn.dataset.histAction);
    renderHistorico($('hist-search').value, $('hist-status').value);
  });

  // --- Export CSV ---
  $('btn-exportar').addEventListener('click', () => {
    if (!sessoes.length) { toast('Nenhum dado para exportar', 'error'); return; }
    const headers = ['ID', 'Data', 'Aluno', 'RA', 'Monitor', 'Disciplina', 'Dia', 'Hora', 'Modalidade', 'Status', 'Duvida'];
    const rows = sessoes.map(s => [s.id, formatDate(s.criadoEm), s.aluno, s.ra, s.monitorNome, s.disciplina, s.dia, s.hora, s.modalidade, s.status, `"${s.duvida}"`]);
    const csv = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `monitoria_historico_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    toast('CSV exportado!', 'success');
  });

  // --- Modal Sessao (close) ---
  $('close-modal-sessao').addEventListener('click', () => $('modal-sessao').classList.remove('show'));

  // --- Close modals on overlay click ---
  document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', e => { if (e.target === overlay) overlay.classList.remove('show'); });
  });

  // --- Week nav (cosmetic) ---
  let weekOffset = 0;
  $('btn-semana-ant').addEventListener('click', () => { weekOffset--; $('week-label').textContent = weekOffset === 0 ? 'Esta semana' : `${weekOffset > 0 ? '+' : ''}${weekOffset} semana(s)`; });
  $('btn-semana-prox').addEventListener('click', () => { weekOffset++; $('week-label').textContent = weekOffset === 0 ? 'Esta semana' : `${weekOffset > 0 ? '+' : ''}${weekOffset} semana(s)`; });

  // --- Init ---
  updateDashboard();
  renderMonitores();
  updateNotifications();
})();
